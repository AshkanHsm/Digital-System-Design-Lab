#ifndef _port_fun_h_INCLUDED_
#define _port_fun_h_INCLUDED_
unsigned int Q1(unsigned int port_in,unsigned int port_out);
unsigned int Q2(unsigned int port_in,unsigned int data_in);
unsigned int Q3(unsigned int n_on_off,unsigned int time_between_on_off);
void Q4(void);
void Q5(unsigned int data_in,char PORT_out,char PORT_en);
#endif