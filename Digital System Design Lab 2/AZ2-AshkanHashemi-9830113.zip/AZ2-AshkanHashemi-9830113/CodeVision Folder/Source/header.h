#ifndef _header_INCLUDED_
#define _header_INCLUDED_

#include <mega16.h>
#include <port_fun_h.h>
#include <delay.h>
#define port_A 1
#define port_B 2
#define port_C 3
#define port_D 4
#endif